<?php include('inc/top.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>ORBIT - VIRTUAL CONFERENCE</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->

<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<script src="assets/js/a076d05399.js"></script>
</head>
<body>

<!-- ======= Header ======= -->

<header id="header">
  <div class="container">
    <div id="logo" class="pull-left"> </div>
    <?php include('inc/nav.php');?>
    <!-- #nav-menu-container --> 
  </div>
</header>

<!-- End Header --> 

<!-- ======= Schedule Section ======= -->
<section id="schedule" class="section-with-bg">
  <div class="container" data-aos="fade-up">
    <div class="section-header">
      <h2>Scientific Program</h2>
      <p>Here is our event schedule</p>
    </div>
    <ul class="nav nav-tabs" role="tablist" data-aos="fade-up" data-aos-delay="100">
      <?php
        $agendas=get_all_agendas("eventid=".$_SESSION['eventdata'][0]['id']." and status=1");
        
        for($i=0;$i<sizeof($agendas);$i++){
          $agenda=$agendas[$i];
      ?>
      <li class="nav-item"> <a class="nav-link <?=($agenda['aday']==1)?'active':''?>" href="#day-<?=$agenda['aday']?>" role="tab" data-toggle="tab">
        <?=$agenda['adate']?>
        </a> </li>
      <?php
        }
      ?>
    </ul>
    <div class="tab-content row justify-content-center" data-aos="fade-up" data-aos-delay="200"> 
      
      <!-- Schdule Days -->
      <?php
        $agendas=get_all_agendas("eventid=".$_SESSION['eventdata'][0]['id']." and status=1");
        
        for($i=0;$i<sizeof($agendas);$i++){
          $agenda=$agendas[$i];          
      ?>
      <div role="tabpanel" class="col-lg-9 tab-pane fade <?=($agenda['aday']==1)?'show active':''?>" id="day-<?=$agenda['aday']?>">
        <div class="row schedule-item">
          <div class="col-md-2">
            <h3>Time</h3>
          </div>
          <div class="col-md-8">
            <h3>Topic & Speaker</h3>
          </div>
          <div class="col-md-2">
            <h3>Hall</h3>
          </div>
          <br>
          <br>
          <br>
        </div>
        <?php
            $agenda_details=get_all_agendadetails('agendaid='.$agenda['id']);
            for($j=0;$j<sizeof($agenda_details);$j++){
            ?>
        <div class="row schedule-item">
          <div class="col-md-2">
            <time>
              <?=$agenda_details[$j]['atime']?>
            </time>
          </div>
          <div class="col-md-8">
            <?php if($agenda_details[$j]['image']){?>
            <div class="speaker"> <img src="<?=$agenda_details[$j]['image']?>" alt="Brenden Legros"> </div>
            <?php }?>
            <h4>
              <?=$agenda_details[$j]['title']?>
              <br>
              <span>
              <?=$agenda_details[$j]['position']?>
              </span></h4>
            <p>
              <?=$agenda_details[$j]['description']?>
            </p>
          </div>
          <div class="col-md-2">
            <time>
              <?=$agenda_details[$j]['hallid']?>
            </time>
          </div>
        </div>
        <?php
            }
            ?>
      </div>
      <?php
        }
      ?>
    </div>
  </div>
</section>

<!-- End Schedule Section --> 
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 

<!-- Vendor JS Files --> 
<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/php-email-form/validate.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 

<!-- Template Main JS File --> 
<script src="assets/js/main.js"></script>
<script src="../analytics/analytics.js"></script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5fb71853920fc91564c8cafc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>