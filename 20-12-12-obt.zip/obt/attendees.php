<?php include('inc/top.php');?>
<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>ORBIT - VIRTUAL CONFERENCE</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/attendees.css" rel="stylesheet">
<script src="assets/js/a076d05399.js"></script>

<script src='https://unpkg.com/nprogress@0.2.0/nprogress.js'></script>
<link rel='stylesheet' href='https://unpkg.com/nprogress@0.2.0/nprogress.css'/>
</head>

<body>

<!-- ======= Header ======= -->
<header id="header">
  <div class="container">
    <div id="logo" class="pull-left"> </div>
    <?php include('inc/nav.php');?>
    
    <!-- #nav-menu-container --> 
  </div>
</header>

<!-- End Header --> 

<!-- ======= Attendees Section ======= -->

<div class="container" style="margin-top:150px;">
  <div class="row bootstrap snippets bootdeys">
    <div class="col-md-9 col-sm-7">
      <h2>Attendees</h2>
    </div>
    <div class="col-md-3 col-sm-5">
      <form method="get" role="form" class="search-form-full" onsubmit="return false;">
        <div class="form-group">
          <input type="text" class="form-control" name="s" id="search-input" placeholder="Search...">
          <i class="entypo-search"></i> </div>
      </form>
    </div>
  </div>
  <div id="attendee">
      <!--<img src="ajax-loader.gif" />-->
      
      
  </div>
  <div class="form">
          <button type="button" id="btn_load_more" name="btn_load_more" style="display:none">LOAD MORE</button>
      </div>
</div>

<!-- End Attendees Section --> 
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 

<!-- Vendor JS Files --> 
<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/php-email-form/validate.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 

<!-- Template Main JS File --> 
<script src="assets/js/main.js"></script>
<script src="../analytics/analytics.js"></script>
<script>
$(document).ready(function(){
    
    load_attendees(function(){
        NProgress.done();
        $('#btn_load_more').fadeIn();
    });
        
    $('#search-input').on('keyup',function(e) {
        if(e.which==13){
        txt=$('#search-input').val();
            search_attendee(txt);
        }else if(e.which==8){
             load_attendees(function(){NProgress.done();});
        }
    });
    
    $('#btn_load_more').click(function(){
        load_more_attendees(function(){
            NProgress.done();
        });
    });
});
function load_attendees(callback){
    NProgress.start();
    var total_attendees=$('.member-entry').length;
    total_attendees=total_attendees+10
    start_cnt=0;
    $.ajax({
            url:'https://rspvirtualmeet.com/obt/attendee_ajax.php?action=fetchall&start='+start_cnt+'&cnt='+total_attendees,
            type:'GET',
            async:true,
            success:function(res){
                $('#attendee').append(res);
                callback();
            }
        }); 
}

function load_more_attendees(callback){
    var total_attendees=10;
    var start_cnt=$('.member-entry').length;
  
    
    $.ajax({
            url:'https://rspvirtualmeet.com/obt/attendee_ajax.php?action=fetchall&start='+start_cnt+'&cnt='+total_attendees,
            type:'GET',
            async:true,
            success:function(res){
                $('#attendee').append(res);
                callback();
            }
        }); 
}


function search_attendee(txt){
    NProgress.start();
      $.ajax({
            url:'https://rspvirtualmeet.com/obt/attendee_ajax.php?action=search&txt='+txt,
            type:'GET',
            async:true,
            success:function(res){
                $('#attendee').empty();
                $('#attendee').append(res);
                NProgress.done();
            }
        }); 
}
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5fb71853920fc91564c8cafc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>