<?php
$icons['Name']='fas fa-user';
$icons['designation']='fas fa-briefcase';
$icons['Institute']='fas fa-building';
$icons['pmdc']='fas fa-user-md' ;
$icons['city']='fas fa-city';
$icons['country']='fas fa-flag';
$icons['contact_no']='fas fa-mobile-alt';
$icons['facebook']='fab fa-facebook-square';
$icons['twitter']='fab fa-twitter-square';
$icons['profile_pic']='fas fa-camera';
$icons['orbit_username']='fas fa-envelope';
$icons['orbit_password']='';




?>