<?php include('inc/top.php');
$msg='';
if(isset($_POST['btn_submit'])){
extract($_POST);
  $eventid=$_SESSION['eventdata'][0]['id'];
  $qry="insert into tbl_helpdesk (cname,email,subject,message,eventid) values('$name','$email','$subject','$message',$eventid)";
  
  if ($conn->query($qry) === TRUE) {
      $msg= "Your message has been sent. Thank you!";
    } else {
      $msg= "Error: " . $qry . "<br>" . $conn->error;
    } 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>ORBIT - VIRTUAL CONFERENCE</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/networking.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.css">
<script src="assets/js/a076d05399.js"></script>
</head>
<body>

<!-- ======= Header ======= -->

<header id="header">
  <div class="container">
    <div id="logo" class="pull-left"> </div>
    <?php include('inc/nav.php');?>
    <!-- #nav-menu-container --> 
    
  </div>
</header>

<!-- End Header --> 

<!-- ======= Intro Section ======= -->

<iframe src="https://tawk.to/chat/5fb71853920fc91564c8cafc/default" frameborder="0" style="overflow:hidden;height:100%;width:100%; position:absolute;top:0px;left:0px;right:0px;bottom:0px" height="100%" width="100%" ></iframe>

<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 

<!-- Vendor JS Files --> 
<!-- <script src="assets/vendor/php-email-form/validate.js"></script>  --> 
<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 

<!-- Template Main JS File --> 
<script src="assets/js/main.js"></script>
<script src="../analytics/analytics.js"></script>
</body>
</html>