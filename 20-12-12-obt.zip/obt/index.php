<?php include('inc/top.php');?>
<?php


$homepage_data=get_homepage_banners("eventid=".$_SESSION['eventdata'][0]['id']);
for($j=0;$j<sizeof($homepage_data);$j++){
  $hpage_data=$homepage_data[$j];
}


/****************** Agenda Ticker DB variables ******************/
$agenda_ticker_data=select("select * from  tbl_agenda_ticker where status=1 and eventid=".$_SESSION['eventdata'][0]['id']);

$agenda_status=$agenda_ticker_data[0]['status'];
$agenda_ticker1=$agenda_ticker_data[0]['agenda_ticker1'];
$agenda_ticker2=$agenda_ticker_data[0]['agenda_ticker2'];
$agenda_ticker3=$agenda_ticker_data[0]['agenda_ticker3'];
/****************** Agenda Ticker DB variables ******************/

?>
<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>ORBIT - VIRTUAL CONFERENCE</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->

<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->

<link href="assets/css/style.css" rel="stylesheet">
<script src="assets/js/a076d05399.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
</head>

<body class="intro" style="overflow:hidden;">

<!-- ======= Header ======= -->

<header id="header">
  <div class="container">
    <div id="logo" class="pull-left"> </div>
    <?php include('inc/nav.php');?>
    <!-- #nav-menu-container --> 
  </div>
</header>
<!-- End Header --> 

<!-- ======= Main Section =======

<a class="exhibition-hall" href="exhibitors.php"></a> <a class="networking-lounge" href="poster.php"></a> <a class="help-desk" href="help-desk.php"></a> <a class="main-plenary" href="scientific-session.php"></a>
<div class="platinium-sponser">
  <?php if($hpage_data['PlatiniumSponserURL']==""){ ?>
  <img src="assets/img/platnium.png">
  <?php } else {?>
  <img src="<?=$hpage_data['PlatiniumSponserURL']?>">
  <?php  } ?>
</div>
<div class="gold-sponser-left">
  <?php if($hpage_data['Gold1SponserURL']==""){ ?>
  <img src="assets/img/gold.png">
  <?php } else {?>
  <img src="<?=$hpage_data['Gold1SponserURL']?>">
  <?php  } ?>
</div>
<div class="silver-sponser-left">
  <?php if($hpage_data['Silver1SponserURL']==""){ ?>
  <img src="assets/img/silver.png">
  <?php } else {?>
  <img src="<?=$hpage_data['Silver1SponserURL']?>">
  <?php  } ?>
</div>
<div class="basic-sponser-left">
  <?php if($hpage_data['Basic1SponserURL']==""){ ?>
  <img src="assets/img/basic.png">
  <?php } else {?>
  <img src="<?=$hpage_data['Basic1SponserURL']?>">
  <?php  } ?>
</div>
<div class="gold-sponser-right">
  <?php if($hpage_data['Gold2SponserURL']==""){ ?>
  <img src="assets/img/gold.png">
  <?php } else {?>
  <img src="<?=$hpage_data['Gold2SponserURL']?>">
  <?php  } ?>
</div>
<div class="silver-sponser-right">
  <?php if($hpage_data['Silver2SponserURL']==""){ ?>
  <img src="assets/img/silver.png">
  <?php } else {?>
  <img src="<?=$hpage_data['Silver2SponserURL']?>">
  <?php  } ?>
</div>
<div class="basic-sponser-right">
  <?php if($hpage_data['Basic2SponserURL']==""){ ?>
  <img src="assets/img/basic.png" >
  <?php } else {?>
  <img src="<?=$hpage_data['Basic2SponserURL']?>" >
  <?php  } ?>
</div>
<a href="https://vimeo.com/showcase/7826384/embed" class="venobox video-pro mb-4" data-vbtype="iframe"><img src="assets/img/video-pro.png" width="200"></a>
<!-- <iframe src="https://vimeo.com/showcase/7826384/embed" frameborder="0" allow="autoplay; fullscreen" allowfullscreen class="venobox video-pro mb-4"></iframe> -->
<!-- <iframe src="<?=$hpage_data['Video1URL']?>" frameborder="0" allow="autoplay; fullscreen" allowfullscreen class="video-pro"></iframe> -->
</div>
-->
<!-- ======= End Main Section ======= --> 
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 
<!-- Vendor JS Files --> 
<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/php-email-form/validate.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 

<!-- Template Main JS File --> 
<script src="assets/js/main.js"></script> 
<script src="../analytics/analytics.js"></script>
<script>
 function login_chat_user()
    {
      chatusername="<?=$_SESSION['userdata']['username']?>";
      chatusername=chatusername.substring(0,chatusername.indexOf('@'));
      chatpassword="<?=$_SESSION['userdata']['_a']?>";
      $.ajax({
              type:'POST',
              url:'../blabax/account.php',
              data:"username="+chatusername+"&password="+chatpassword,
              success:function(res){
                    //location.href="blabax/blabax.php"
                    
                  }            
              });      
      }



      //login_chat_user();
</script>

<!-- 
<div class="ticker"><marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"><b>Scientific Program</b>: <a href="agenda.php"><?=$agenda_ticker1 ?> | <?=$agenda_ticker2 ?> | <?=$agenda_ticker3 ?></a></marquee></div>
-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5fb71853920fc91564c8cafc/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>