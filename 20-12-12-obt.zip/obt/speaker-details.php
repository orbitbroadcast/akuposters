<?php

include('inc/top.php');
$biographies=get_all_biographies('id='.$_GET['id']);

$bography=$biographies[0];

?>
<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>Speaker Details</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->

<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->

<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->

<link href="assets/css/style.css" rel="stylesheet">
</head>

<body>
<section id="speakers-details">
  <div class="container">
    <div class="section-header">
      <h2>Speaker Details</h2>
      <p>
        <?=$bography['position']?>
      </p>
    </div>
    <div class="row">
      <div class="col-md-6"> <img src="../<?=$bography['image']?>" alt="Speaker 1" class="img-fluid"> </div>
      <div class="col-md-6">
        <div class="details">
          <h2>
            <?=$bography['title']?>
          </h2>
          <div class="social">
            <?php if($bography['twitter']!=""){ ?>
            <a href="<?=$bography['twitter']?>" target="_blank"><i class="fa fa-twitter"></i></a>
            <?php }?>
            <?php if($bography['facebook']!=""){ ?>
            <a href="<?=$bography['facebook']?>" target="_blank"><i class="fa fa-facebook"></i></a>
            <?php }?>
            <?php if($bography['google']!=""){ ?>
            <a href="<?=$bography['google']?>" target="_blank"><i class="fa fa-google-plus"></i></a>
            <?php }?>
            <?php if($bography['linkedin']!=""){ ?>
            <a href="<?=$bography['linkedin']?>" target="_blank"><i class="fa fa-linkedin"></i></a>
            <?php }?>
          </div>
          <?=$bography['description']?>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
</div>
<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 

<!-- Vendor JS Files --> 

<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/php-email-form/validate.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 
<script src="../analytics/analytics.js"></script>
<!-- Template Main JS File --> 

<script src="assets/js/main.js"></script>
</body>
</html>