<?php include('inc/top.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<title>ORBIT - VIRTUAL CONFERENCE</title>
<meta content="" name="descriptison">
<meta content="" name="keywords">

<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
<link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
<link href="assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
<link href="assets/vendor/aos/aos.css" rel="stylesheet">

<!-- Template Main CSS File -->
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<script src="assets/css/jquery.slim.min.js"></script>
<script src="assets/css/bootstrap.bundle.min.js"></script>
<script src="assets/js/a076d05399.js"></script>
</head>
<body class="stall-bg" style="background-image: url(/uploads/ext/stall10.jpg);">

<!-- ======= Header ======= -->

<header id="header">
  <div class="container">
    <div id="logo" class="pull-left"> </div>
    <?php include('inc/nav.php');?>
    <!-- #nav-menu-container --> 
    
  </div>
</header>
<!-- End Header --> 

<!-- ======= Exhibitors Section ======= -->

<a href="exhibitors.php" class="close"><i class="fas fa-times-circle"></i></a>

<?php

$id=$_GET['id'];
$exhibitors=get_all_exhibitors("id=10");
$exhibitor=$exhibitors[0];

$poster1=@explode(".",str_replace('../','',$exhibitor['poster1']))[1];
$poster2=@explode(".",str_replace('../','',$exhibitor['poster2']))[1];
$pdf1=@explode(".",str_replace('../','',$exhibitor['pdf1']))[1];
$pdf2=@explode(".",str_replace('../','',$exhibitor['pdf2']))[1];
$pdf5=@explode(".",str_replace('../','',$exhibitor['pdf5']))[1];

?>
<div id="options"> <a href="exhibitors.php" class="exhibitors-hall-icon">Exhibitors Hall</a>
  <?php if(strlen($exhibitor['videourl'])>0){ ?>
  <div class="session-container" ><!--data-aos="zoom-in" data-aos-delay="100"--> 
    <a href="<?=$exhibitor['videourl']?>" class="venobox video-icon mb-4" data-vbtype="video" data-autoplay="true">Video</a> </div>
  <?php } ?>
  <?php if(strlen($poster1)>0){ ?>
  <a href="<?=$exhibitor['poster1']?>" target="_blank" class="pdf-icon">Poster 1</a>
  <?php } ?>
  <?php if(strlen($poster2)>0){ ?>
  <a href="<?=$exhibitor['poster2']?>" target="_blank"  class="pdf-icon">Poster 2</a>
  <?php } ?>
  <?php if(strlen($pdf1)>0){ ?>
  <a href="<?=$exhibitor['pdf1']?>" target="_blank"  class="pdf-icon">Poster 3</a>
  <?php } ?>
  <?php if(strlen($pdf2)>0){ ?>
  <a href=".<?=$exhibitor['pdf2']?>" target="_blank"  class="pdf-icon">Poster 4</a>
  <?php } ?>
  <?php if(strlen($pdf5)>0){ ?>
  <a href=".<?=$exhibitor['pdf5']?>"  target="_blank" class="pdf-icon">Poster 5</a>
  <?php }?>
  <a href="video-chat.php?url=https://meet.jit.si/IRsp" class="video-chat-icon venobox video-icon mb-4" data-vbtype="iframe">Video Chat</a>
</div>

<!-- End Exhibitors Section --> 

<a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a> 

<!-- Vendor JS Files --> 
<script src="assets/vendor/jquery/jquery.min.js"></script> 
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script> 
<script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script> 
<script src="assets/vendor/php-email-form/validate.js"></script> 
<script src="assets/vendor/venobox/venobox.min.js"></script> 
<script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script> 
<script src="assets/vendor/superfish/superfish.min.js"></script> 
<script src="assets/vendor/hoverIntent/hoverIntent.js"></script> 
<script src="assets/vendor/aos/aos.js"></script> 

<!-- Template Main JS File --> 
<script src="assets/js/main.js"></script> 
<script src="../analytics/analytics.js"></script>
<!--Start of Tawk.to Script--> 
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5fb5eb80920fc91564c86b17/1enfa08s0';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script> 
<!--End of Tawk.to Script-->
</body>
</html>