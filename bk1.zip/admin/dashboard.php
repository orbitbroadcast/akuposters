<?php include('inc/header.php'); ?>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          
          <!-- Main row -->
          <div class="row">
              <ul class="cards">
                  <li class="totalusers">
                      <div id="value"></div>
                      <div id="title"></div>
                  </li>
                  <li class="totalloggedinusers">
                      <div id="value"></div>
                      <div id="title"></div>
                  </li>
                </ul>
          </div>
          <div class="row">
              <div class="col-sm-6">
              <div class="user-page-hit">
                  
              </div>
                </div>
                <div class="col-sm-6">
              <div class="ip-location">
                  <table>
                      <tr>
                          <th>Location</th>
                          <th>Total Hits</th>
                          <th>Country Code</th>
                      </tr>
                      
                  </table>
              </div>
              </div>
          </div>
          <!-- /.row (main row) -->

        </section><!-- /.content -->

   

<?php include('inc/footer.php');?>